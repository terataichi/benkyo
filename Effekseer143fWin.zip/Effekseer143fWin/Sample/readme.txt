﻿All the licenses of these effects are CC-0.
We'd appreciate it if you could credit Effekseer and a contributor somewhere in your works.

A sample stored in this directory is only part of sample.
You can download other effects from the official site.

CC-0
http://creativecommons.org/about/cc0

これらのエフェクトのライセンスは全てCC-0です。
ただ、できれば使用した場合は作品のどこかにEffekseerと投稿者の名前を記述していただけると幸いです。

このディレクトリに保存されているサンプルは一部のみです。
他のエフェクトは公式サイトからダウンロードできます。

CC-0
http://sciencecommons.jp/cc0/about